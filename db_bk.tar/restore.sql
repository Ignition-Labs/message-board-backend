--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 15.4
-- Dumped by pg_dump version 15.4

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE erm;
--
-- Name: erm; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE erm WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.UTF-8';


ALTER DATABASE erm OWNER TO postgres;

\connect erm

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: mapping; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.mapping (
    id integer NOT NULL,
    code character(6) NOT NULL,
    code_connected text NOT NULL
);


ALTER TABLE public.mapping OWNER TO postgres;

--
-- Name: mapping_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.mapping_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.mapping_id_seq OWNER TO postgres;

--
-- Name: mapping_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.mapping_id_seq OWNED BY public.mapping.id;


--
-- Name: msg; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.msg (
    id integer NOT NULL,
    code character(6) NOT NULL,
    address character(42),
    content text,
    create_time timestamp without time zone NOT NULL,
    region character varying(50),
    name character varying(16),
    avatar text,
    expire boolean
);


ALTER TABLE public.msg OWNER TO postgres;

--
-- Name: msg_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.msg_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.msg_id_seq OWNER TO postgres;

--
-- Name: msg_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.msg_id_seq OWNED BY public.msg.id;


--
-- Name: mapping id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mapping ALTER COLUMN id SET DEFAULT nextval('public.mapping_id_seq'::regclass);


--
-- Name: msg id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.msg ALTER COLUMN id SET DEFAULT nextval('public.msg_id_seq'::regclass);


--
-- Data for Name: mapping; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.mapping (id, code, code_connected) FROM stdin;
\.
COPY public.mapping (id, code, code_connected) FROM '$$PATH$$/4293.dat';

--
-- Data for Name: msg; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.msg (id, code, address, content, create_time, region, name, avatar, expire) FROM stdin;
\.
COPY public.msg (id, code, address, content, create_time, region, name, avatar, expire) FROM '$$PATH$$/4291.dat';

--
-- Name: mapping_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.mapping_id_seq', 750, true);


--
-- Name: msg_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.msg_id_seq', 150, true);


--
-- Name: mapping mapping_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mapping
    ADD CONSTRAINT mapping_pkey PRIMARY KEY (id);


--
-- Name: msg msg_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.msg
    ADD CONSTRAINT msg_pkey PRIMARY KEY (id);


--
-- Name: mapping_code_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX mapping_code_idx ON public.mapping USING btree (code);


--
-- PostgreSQL database dump complete
--

